// ===== FOTOS =====
// Coloque as fotos na pasta "img" do repositório e escreva o nome do arquivo em "foto".
// Se a foto não existir, o site mostra a inicial da jogadora automaticamente.
// Em "credito" escreva autor, licença e fonte da foto (aparece no rodapé).
const jogadoras = [
 {nome:"Marta Vieira da Silva",apelido:"Marta, Rainha Marta",pais:"Brasil",pos:"Atacante",nasc:"19/02/1986, Dois Riachos (AL)",clubes:"Umeå, Rosengård, Orlando Pride",
  desc:"Uma das maiores referências da história do futebol. Sua habilidade, seus gols e sua trajetória pela Seleção marcaram gerações.",
  dest:"Seis vezes melhor jogadora do mundo pela FIFA e maior artilheira da história das Copas, com 17 gols.",foto:"images.jpg.marta.jpg",credito:""},
 {nome:"Miraildes Maciel Mota",apelido:"Formiga",pais:"Brasil",pos:"Volante",nasc:"03/03/1978, Salvador (BA)",clubes:"São Paulo, Paris Saint-Germain",
  desc:"Volante histórica da Seleção, reconhecida pela longevidade e pela presença em grandes competições.",
  dest:"Disputou sete Copas do Mundo e sete Olimpíadas. Prata olímpica em 2004 e 2008.",foto:"images.jpg.miraildes.jpg",credito:""},
 {nome:"Cristiane Rozeira de Souza Silva",apelido:"Cristiane",pais:"Brasil",pos:"Atacante",nasc:"15/05/1985, Osasco (SP)",clubes:"Santos, Corinthians, Chicago Red Stars",
  desc:"Atacante conhecida pela presença ofensiva e por gols importantes com a Seleção.",
  dest:"Prata olímpica em 2004 e 2008 e vice-campeã mundial em 2007.",foto:"oanccvoazucrx97hqvvb.avif.cristiane.avif",credito:""},
 {nome:"Sisleide do Amor Lima",apelido:"Sissi",pais:"Brasil",pos:"Meio-campista",nasc:"02/06/1967, Esplanada (BA)",clubes:"Saad, Vasco",
  desc:"Pioneira da Seleção, uma das jogadoras mais habilidosas de sua geração.",
  dest:"Artilheira da Copa do Mundo de 1999, com 7 gols, e bronze naquele torneio.",foto:"images.jpg.sissi.jpg",credito:""},
 {nome:"Alexia Putellas Segura",apelido:"Alexia",pais:"Espanha",pos:"Meio-campista",nasc:"04/02/1994, Mollet del Vallès",clubes:"Barcelona",
  desc:"Meio-campista conhecida pela técnica, visão de jogo e liderança no Barcelona e na seleção espanhola.",
  dest:"Duas Bolas de Ouro (2021 e 2022).",foto:"images.jpg.alexia.jpg",credito:""},
 {nome:"Aitana Bonmatí Conca",apelido:"Aitana",pais:"Espanha",pos:"Meio-campista",nasc:"18/01/1998, Sant Pere de Ribes",clubes:"Barcelona",
  desc:"Meio-campista que se destaca pela qualidade nos passes, pela inteligência de jogo e pela participação em títulos.",
  dest:"Campeã mundial em 2023 e vencedora da Bola de Ouro em 2023, 2024 e 2025.",foto:"aitana.jpg",credito:""},
 {nome:"Megan Anna Rapinoe",apelido:"Pinoe",pais:"Estados Unidos",pos:"Atacante",nasc:"05/07/1985, Redding (EUA)",clubes:"Seattle Reign, OL Reign",
  desc:"Ex-jogadora lembrada pela atuação em campo e pela defesa da igualdade no esporte.",
  dest:"Campeã mundial em 2015 e 2019, ouro olímpico em 2012.",foto:"rapinoe.jpg",credito:""},
 {nome:"Mariel Margaret Hamm",apelido:"Mia Hamm",pais:"Estados Unidos",pos:"Atacante",nasc:"17/03/1972, Selma (EUA)",clubes:"Washington Freedom",
  desc:"Uma das grandes pioneiras do futebol feminino norte-americano e referência para muitas atletas.",
  dest:"Bicampeã mundial (1991 e 1999) e bicampeã olímpica (1996 e 2004).",foto:"images.jpg.mariel.jpg",credito:""}
];
const historia = [
 ["1921","A Federação Inglesa proíbe clubes ligados à entidade de receber partidas femininas em seus campos."],
 ["1941","No Brasil, um decreto proíbe mulheres de praticar esportes considerados incompatíveis com sua “natureza”."],
 ["1979","A proibição brasileira é revogada, abrindo caminho para a organização do futebol feminino."],
 ["1991","A China sedia a primeira Copa do Mundo Feminina organizada pela FIFA."],
 ["1996","O futebol feminino estreia nos Jogos Olímpicos de Atlanta."],
 ["2023","A Espanha é campeã mundial, na Austrália e na Nova Zelândia."],
 ["2027","O Brasil sedia a Copa do Mundo Feminina."]
];
const $ = s => document.querySelector(s);
$("#timeline").innerHTML = historia.map(([a,t]) => `<div class="card"><b>${a}</b><p>${t}</p></div>`).join("");

function render(pais){
 $("#players").innerHTML = jogadoras.filter(j => !pais || j.pais === pais).map(j => `
  <article class="player">
   <div class="photo">${j.foto ? `<img src="${j.foto}" alt="Foto de ${j.apelido.split(",")[0]}" onload="this.nextElementSibling.hidden=true" onerror="this.remove()">` : ""}<span>${j.nome[0]}</span></div>
   <div>
    <p class="pais">${j.pais.toUpperCase()}</p>
    <h3>${j.nome}</h3>
    <p class="apelido">Conhecida como: ${j.apelido}</p>
    <p>${j.desc}</p>
    <p class="dest">${j.dest}</p>
    <dl><dt>Posição</dt><dd>${j.pos}</dd><dt>Nascimento</dt><dd>${j.nasc}</dd><dt>Clubes</dt><dd>${j.clubes}</dd></dl>
   </div>
  </article>`).join("");
}
const paises = [...new Set(jogadoras.map(j => j.pais))];
$("#filters").innerHTML = ["Todas", ...paises].map((p,i) => `<button aria-pressed="${i===0}" data-p="${i?p:""}">${p}</button>`).join("");
$("#filters").addEventListener("click", e => {
 const b = e.target.closest("button"); if(!b) return;
 document.querySelectorAll("#filters button").forEach(x => x.setAttribute("aria-pressed", x === b));
 render(b.dataset.p);
});
render("");

const cred = jogadoras.filter(j => j.credito);
$("#credits").innerHTML = cred.length ? cred.map(j => `<li>${j.apelido.split(",")[0]}: ${j.credito}</li>`).join("") : "<li>Adicione o crédito de cada foto no campo “credito” do arquivo script.js.</li>";

const burger = $("#burger"), menu = $("#menu");
burger.addEventListener("click", () => { const o = menu.classList.toggle("open"); burger.setAttribute("aria-expanded", o); });
menu.addEventListener("click", e => { if (e.target.tagName === "A") { menu.classList.remove("open"); burger.setAttribute("aria-expanded", false); } });
