const menuToggle = document.getElementById('menuToggle');
const menu = document.getElementById('menu');

menuToggle.addEventListener('click', () => {
  const aberto = menu.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', aberto);
});

document.querySelectorAll('#menu a').forEach(link => {
  link.addEventListener('click', () => {
    menu.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
  });
});

const curiosidades = [
  'A primeira Copa do Mundo Feminina da FIFA aconteceu em 1991, na China.',
  'Marta foi eleita seis vezes a melhor jogadora do mundo pela FIFA.',
  'Formiga participou de sete edições dos Jogos Olímpicos.',
  'O futebol feminino é praticado em clubes, escolas, projetos sociais e seleções em vários países.',
  'As categorias de base são importantes para desenvolver novos talentos e ampliar oportunidades.'
];
let factIndex = 0;
document.getElementById('newFact').addEventListener('click', () => {
  factIndex = (factIndex + 1) % curiosidades.length;
  document.getElementById('factText').textContent = curiosidades[factIndex];
});

const perguntas = [
  {
    pergunta: 'Qual país sediou a primeira Copa do Mundo Feminina da FIFA, em 1991?',
    respostas: ['Brasil', 'China', 'Estados Unidos'],
    correta: 1
  },
  {
    pergunta: 'Qual jogadora brasileira foi eleita seis vezes a melhor do mundo pela FIFA?',
    respostas: ['Marta', 'Formiga', 'Cristiane'],
    correta: 0
  },
  {
    pergunta: 'Quantas edições dos Jogos Olímpicos Formiga disputou?',
    respostas: ['Três', 'Cinco', 'Sete'],
    correta: 2
  }
];
let perguntaAtual = 0;
let respondida = false;

function mostrarPergunta() {
  const atual = perguntas[perguntaAtual];
  document.getElementById('question').textContent = atual.pergunta;
  document.getElementById('quizResult').textContent = '';
  const answers = document.getElementById('answers');
  answers.innerHTML = '';
  respondida = false;

  atual.respostas.forEach((resposta, indice) => {
    const botao = document.createElement('button');
    botao.textContent = resposta;
    botao.addEventListener('click', () => {
      if (respondida) return;
      respondida = true;
      const botoes = answers.querySelectorAll('button');
      botoes[atual.correta].classList.add('correct');
      if (indice === atual.correta) {
        document.getElementById('quizResult').textContent = 'Muito bem! Você acertou!';
      } else {
        botao.classList.add('wrong');
        document.getElementById('quizResult').textContent = 'Quase! A resposta correta está destacada.';
      }
    });
    answers.appendChild(botao);
  });
}

document.getElementById('nextQuestion').addEventListener('click', () => {
  perguntaAtual = (perguntaAtual + 1) % perguntas.length;
  mostrarPergunta();
});

mostrarPergunta();
