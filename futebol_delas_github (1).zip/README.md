# FUTEBOL DELAS

Site informativo sobre a história, as conquistas e as grandes jogadoras do futebol feminino.

## Arquivos
- `index.html`: estrutura e conteúdo do site.
- `style.css`: cores, organização e adaptação para celular.
- `script.js`: menu, curiosidades e quiz.

## Como visualizar
Abra o arquivo `index.html` no navegador.

## Como publicar pelo GitHub Pages
1. Entre no GitHub e crie um repositório público chamado `futebol-delas`.
2. Envie os três arquivos (`index.html`, `style.css` e `script.js`) para a página principal do repositório.
3. Abra **Settings** > **Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`, depois clique em **Save**.
6. Aguarde o GitHub gerar o endereço do site. Ele aparecerá na própria tela do Pages.

Observação: a imagem de fundo e a fonte externa precisam de internet. As fichas das jogadoras usam iniciais; se adicionar fotografias, utilize imagens com licença ou autorização e inclua os créditos.
