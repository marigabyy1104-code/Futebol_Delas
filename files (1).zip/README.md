# Futebol Delas ⚽

Valorizando o futebol feminino: história, craques, competições, curiosidades e agenda de jogos.

## Como usar
Abra `index.html` no navegador.

## O que tem no site
- O que é o futebol feminino, regras básicas e posições
- Linha do tempo, do século XIX até a Copa de 2027 no Brasil
- Craques com nome completo, apelido, posição e resumo (filtro por país)
- Competições e campeãs da Copa do Mundo
- Curiosidades e como apoiar
- Votação "Quem é a sua craque?" (salva no navegador)
- Agenda de jogos (edite a lista `JOGOS` em `index.html`)

## Como adicionar uma jogadora
Em `index.html`, adicione um objeto na lista `JOGADORAS` com `n`, `full`, `ap`, `pos`, `pais`, `flag`, `nasc` e `txt`.

## Publicar no GitHub Pages
1. Crie um repositório e envie `index.html` e `README.md`.
2. Em **Settings → Pages**, escolha a branch `main` e a pasta `/ (root)`.
3. O site ficará em `https://SEU-USUARIO.github.io/NOME-DO-REPO/`.

## Próximas ideias
- Fotos (com licença), notícias, quiz, mapa de estádios e tabela do Brasileirão Feminino via API
